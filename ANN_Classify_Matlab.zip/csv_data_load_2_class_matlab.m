clear all, close all, clc

%With the file 'grade_ave.mat* in the same foler, run:

load('grade_ave.mat')
input = gradeave(:, 1:35);
target = gradeave(:, 38);

